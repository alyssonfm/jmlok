#!/bin/bash
source $HOME/.profile
java -jar JMLOK-Tool.jar 
